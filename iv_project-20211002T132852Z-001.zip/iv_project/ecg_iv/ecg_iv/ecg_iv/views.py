from django.http import HttpResponse
from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
import stats
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import statistics
from scipy.io import loadmat

def index(request):

    return render(request, 'index.html')

    # return HttpResponse("Home")
datamain = None
def range(request):
    if request.method == 'POST':
        file = request.FILES['fileupload']
        mat = loadmat(file)
        mat = {k: v for k, v in mat.items() if k[0] != '_'}
        data = pd.DataFrame({k: pd.Series(i[0] for i in v) for k, v in mat.items()})
        data2 = pd.DataFrame(mat['Time_Adjusted'].reshape(7200, 1))
        data['Time_Adjusted'] = data2
        global datamain
        def datamain():
            return data
        print(data)
    return render(request, 'range.html')
datamain = None
def analyze(request):
    import json
    if request.method == 'POST':
        range_1 = request.POST.get('rangeone')
        range_2 = request.POST.get('rangetwo')
        print(range_1, range_2)
        k=datamain()
        list = [['Time','Data']]
        req_ecg1 = []
        req_ecg2 = []
        req_time = []
        req_data = pd.DataFrame()
        for x in k.index:
            if k['Time_Adjusted'][x] >= float(range_1) and k['Time_Adjusted'][x] <= float(range_2):
                list1 =[]
                req_ecg1.append(k['ECG_1'][x])
                req_ecg2.append(k['ECG_2'][x])
                req_time.append(k['Time_Adjusted'][x])
                list1 = [k['Time_Adjusted'][x],k['ECG_1'][x]]
                list.append(list1)
        req_data['ECG_1'] = req_ecg1
        req_data['ECG_2'] = req_ecg2
        req_data['Time_Adjusted'] = req_time
        mean = round(sum(req_data['ECG_1'])/len(req_data['ECG_1']),3)
        median = round(statistics.median(req_data['ECG_1']),3)
        mode = round(statistics.mode(req_data['ECG_1']),3)
        stddev = round(statistics.stdev(req_data['ECG_1']),3)
        Q1 = round(np.percentile(req_data['ECG_1'], 25, interpolation='midpoint'),3)
        Q3 = round(np.percentile(req_data['ECG_1'], 75, interpolation='midpoint'),3)
        IQR = round(Q3 - Q1,3)
        list = json.dumps(list)
        sending_data = {'mean': mean, 'median': median, 'mode': mode, 'stddev': stddev, 'Qone': Q1, 'Qthree': Q3, 'IQR': IQR, 'list':list}
    return render(request, 'analyze.html',sending_data)

def aboutus(request):

    return render(request,'aboutus.html')